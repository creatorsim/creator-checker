.data


.text
	main: